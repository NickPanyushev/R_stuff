#include "random.h"

void sRandom(unsigned int seed) {
	init_genrand(seed);
}
//
//inline double Random() 
//{ 
//	return genrand_real2();
//}
